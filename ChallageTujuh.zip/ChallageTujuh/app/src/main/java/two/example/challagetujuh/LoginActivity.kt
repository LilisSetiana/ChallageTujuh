package two.example.challagetujuh

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import two.example.challagetujuh.Model.DataUserResponseItem


@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {

    private lateinit var dataUserManager: DataUserManager
    private lateinit var viewModel : ViewModelUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dataUserManager = DataUserManager(this)

        goToRegister()
        login()

    }

    // ===================================== PROSES LOGIN =============================================//
    private fun login(){
        btn_login.setOnClickListener {
            getApiViewModel()
        }
    }


    private fun getApiViewModel(){
        viewModel = ViewModelProvider(this).get(ViewModelUser::class.java)
        viewModel.login.observe(this){
            if (it.isNotEmpty()) {
                proses(it)
            }
        }
    }


    private fun proses(dataUser : List<DataUserResponseItem>){
        val email = masukan_email_login.text.toString()
        val password = masukan_password_login.text.toString()

        when {
            email.isEmpty() -> {
                Toast.makeText(this, "Email Harus Di Isi", Toast.LENGTH_SHORT).show()
            }
            password.isEmpty() -> {
                Toast.makeText(this, "Password Harus Di Isi", Toast.LENGTH_SHORT).show()
            }
            else -> {
                for (i in dataUser.indices){
                    when {
                        email == dataUser[i].email && password == dataUser[i].password -> {
                            GlobalScope.launch {
                                dataUserManager.checkData(true)
                                dataUserManager.saveData(
                                    dataUser[i].id,
                                    dataUser[i].username,
                                    dataUser[i].email,
                                    dataUser[i].password,
                                    dataUser[i].fullName,
                                    dataUser[i].dateOfBirth,
                                    dataUser[i].address,
                                    dataUser[i].image
                                )
                            }
                            Toast.makeText(this, "Login Sukses", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, HomeActivity::class.java))
                            finish()
                        }
                        email != dataUser[i].email && password != dataUser[i].password -> {
                            Toast.makeText(this, "Login Gagal", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

    }


    // ======================================== GO TO REGISTER ========================================//
    private fun goToRegister(){
        belum_punya_akun.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            finish()
        }
    }

}