package two.example.challagetujuh

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import two.example.challagetujuh.Model.DataUserResponseItem
import two.example.challagetujuh.Model.PostRequest
import two.example.challagetujuh.Network.ApiClient

class ViewModelRegister : ViewModel() {
    var liveDataUserRegister : MutableLiveData<DataUserResponseItem?> = MutableLiveData()

    fun getLiveRegister() : MutableLiveData<DataUserResponseItem?> {
        return liveDataUserRegister
    }


    fun makeApiRegister(username : String, email : String, password : String){
        ApiClient.instance.postDataUser(PostRequest(email, password, username))
            .enqueue(object : Callback<DataUserResponseItem> {
                override fun onResponse(
                    call: Call<DataUserResponseItem>,
                    response: Response<DataUserResponseItem>
                ) {
                    if (response.isSuccessful){
                        liveDataUserRegister.postValue(response.body())
                    } else {
                        liveDataUserRegister.postValue(null)
                    }
                }

                override fun onFailure(call: Call<DataUserResponseItem>, t: Throwable) {
                    liveDataUserRegister.postValue(null)
                }

            })
    }
}