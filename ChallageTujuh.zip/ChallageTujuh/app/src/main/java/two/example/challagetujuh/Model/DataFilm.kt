package two.example.challagetujuh.Model

class DataFilm : ArrayList<DataFilmItem>()