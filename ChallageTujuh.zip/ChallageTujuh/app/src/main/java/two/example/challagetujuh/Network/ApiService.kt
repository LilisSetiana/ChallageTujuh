package two.example.challagetujuh.Network

import retrofit2.Call
import retrofit2.http.*
import two.example.challagetujuh.Model.DataFilmItem
import two.example.challagetujuh.Model.DataUserResponseItem
import two.example.challagetujuh.Model.PostRequest
import two.example.challagetujuh.Model.PutRequest

interface ApiService {

    // get data film
    @GET("film")
    suspend fun getAllFilm() : List<DataFilmItem>

    // post data register
    @POST("user")
    fun postDataUser (
        @Body request : PostRequest
    ) : Call<DataUserResponseItem>

    // get login
    @GET("user")
    suspend fun getDataUser() : List<DataUserResponseItem>

    // update user
    @PUT("user/{id}")
    fun updateDataUser(
        @Path("id") id : String,
        @Body requestUpdate : PutRequest
    ) : Call<List<DataUserResponseItem>>

}