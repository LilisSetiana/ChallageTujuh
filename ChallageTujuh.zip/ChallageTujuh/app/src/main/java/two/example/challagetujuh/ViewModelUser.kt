package two.example.challagetujuh

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import two.example.challagetujuh.Model.DataUserResponseItem
import two.example.challagetujuh.Network.ApiService
import javax.inject.Inject

@HiltViewModel
class ViewModelUser @Inject constructor(apiService: ApiService) : ViewModel(){

    private val userLogin = MutableLiveData<List<DataUserResponseItem>>()
    val login : LiveData<List<DataUserResponseItem>> = userLogin

    init {
        viewModelScope.launch {
            val dataLogin = apiService.getDataUser()

            userLogin.value = dataLogin
        }
    }

}