package two.example.challagetujuh.FilmItem

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import two.example.challagetujuh.R

class ListingFilmItem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listing_film_item)
    }
}