package two.example.challagetujuh.Model

class DataUserResponse : ArrayList<DataUserResponseItem>()